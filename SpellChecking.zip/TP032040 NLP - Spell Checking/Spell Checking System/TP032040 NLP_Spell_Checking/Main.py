##################################################################################################################################
# Python code for Spell Checking system by using Levenshtein edit distance
# This project is part of Natural Language Processing individual assignment as part of Data Science and Business Analytics course
# Code written by student with ID TP032040
# Intake batch: UCMF1610DSBA
##################################################################################################################################

# import libraries
from tkinter import *
import tkinter.messagebox
from tkinter import filedialog
import os
import nltk
from pdfminer.pdfparser import PDFParser, PDFDocument
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import PDFPageAggregator
from pdfminer.layout import LAParams, LTTextBox, LTTextLine
import re
from Levenshtein import levenshtein

# declare global variable
tempdir = ""
dictType = 0

# generate main window
root = Tk()
root.title("TP032040 Spell Checking System")
# geometry manager
root.geometry("700x445")
# disable resize
#root.resizable(0, 0)

# function to load Text file
def browseFileTokenize():
    # get same directory with where the program located
    currdir = os.getcwd()
    # open filedialog
    tempdir = filedialog.askopenfilename(parent=root, initialdir=currdir, filetypes = (("Text File" , "*.txt"),("All Files","*.*")), title="Please select a directory")
    # prompt user that file location is not found
    if len(tempdir) < 1:
        tkinter.messagebox.showinfo('Load File', 'No file is selected')
    else:
        # file location is found
        # show messagebox
        tkinter.messagebox.showinfo('Text Extraction',
                                    'Please wait while the text is being extracted.\nKindly note that this process can take longer time for huge text file size.')
        # delete listbox content
        dictionarylb.delete(0, END)
        # read file content into text
        tempdata = open(tempdir).read()
        # remove symbols, numbers
        tempdata = re.sub('[^a-zA-Z]+', ' ', tempdata)
        # change text contents to lowercase and tokenize
        tokens = nltk.word_tokenize(tempdata.lower())
        # get total number of words in corpus
        wordEntry.delete(0, END)
        wordEntry.insert(0, len(tokens))
        # remove duplicates
        redup = set()
        ntokens = []
        for item in tokens:
            if item not in redup:
                redup.add(item)
                ntokens.append(item)
        # write sorted strings to listbox
        for word in sorted(ntokens):
            dictionarylb.insert(END, word)
        # save filtered list of words to text file
        with open("Tokentextlist.txt", "w", encoding='utf8') as tokenlist:
            for item in ntokens:
                    tokenlist.write(item + "\n")
        # show messagebox
        tkinter.messagebox.showinfo('Text Extraction', 'Text has been extracted successfully!')
        dictType=0

# function to load PDF file
def browsepdfFileTokenize():
    currdir = os.getcwd()
    tempdir = filedialog.askopenfilename(parent=root, initialdir=currdir, filetypes = (("PDF File" , "*.pdf"),("All Files","*.*")), title="Please select a PDF File")
    if len(tempdir) < 1:
        tkinter.messagebox.showinfo('Load File', 'No file is selected')
    else:
        # show messagebox
        tkinter.messagebox.showinfo('PDF-Text Extraction',
                                    'Please wait while the text is being extracted.\nKindly note that this process can take longer time for huge PDF file size.')
        # extract text from pdf
        # open and read pdf file in binary mode
        pdffile = open(tempdir, 'rb')
        # create parser object to parse the pdf content
        parser = PDFParser(pdffile)
        # store parsed content in PDFDocument object
        doc = PDFDocument()
        parser.set_document(doc)
        doc.set_parser(parser)
        doc.initialize('')
        # create PDFResourceManager object to store fonts or images
        rsrcmgr = PDFResourceManager()
        # set parameters for analysis
        laparams = LAParams()
        # extract the device to page aggregator to get LT object elements
        device = PDFPageAggregator(rsrcmgr, laparams=laparams)
        # create interpreter object to process page content from PDFDocument
        interpreter = PDFPageInterpreter(rsrcmgr, device)
        extracted_text = ''
        # process a pdf document page by page
        for page in doc.get_pages():
            interpreter.process_page(page)
            layout = device.get_result()
            for lt_obj in layout:
                if isinstance(lt_obj, LTTextBox) or isinstance(lt_obj, LTTextLine):
                    extracted_text += lt_obj.get_text()
        # close pdf file
        pdffile.close()
        # save to text file
        with open("PDF2Text.txt", "w", encoding='utf8') as f:
            f.write(extracted_text)
        # delete listbox content
        dictionarylb.delete(0, END)
        # read file content into text
        with open("PDF2Text.txt", 'r', encoding='utf8') as f:
            tempdata = f.read()
        # remove symbols, numbers
        tempdata = re.sub('[^a-zA-Z]+', ' ', tempdata)
        # change text contents to lowercase and tokenize
        tokens = nltk.word_tokenize(tempdata.lower())
        # get total number of words in corpus
        wordEntry.delete(0, END)
        wordEntry.insert(0, len(tokens))
        # remove duplicates
        redup = set()
        ntokens = []
        for item in tokens:
            if item not in redup:
                redup.add(item)
                ntokens.append(item)
        # write sorted strings to listbox
        for word in sorted(ntokens):
            dictionarylb.insert(END, word)
        # save filtered list of words to text file
        with open("Tokenpdflist.txt", "w", encoding='utf8') as tokenlist:
            for item in ntokens:
                tokenlist.write(item + "\n")
        # show messagebox
        tkinter.messagebox.showinfo('PDF-Text Extraction', 'Text has been extracted successfully!')
        dictType=1

# function to search word from dictionary
def searchItem():
    # get word to search from text entry
    tempsearch = searchEntry.get()
    # check if word exists in dictionary
    try:
        index = dictionarylb.get(0, "end").index(tempsearch)
    except ValueError:
        index = -1
    # if word exists in dictionary
    if(index > -1):
    # select searched word
        dictionarylb.select_set(index)
    # move screen to searched word
        dictionarylb.see(index)
    # show messagebox
        tkinter.messagebox.showinfo('Search Word', 'Word has been found!')
    else:
        # show messagebox
        tkinter.messagebox.showinfo('Search Word', 'Word cannot be found in the dictionary.')

# function to check spelling error by using dictionary lookup
def spellCheck():
    count = 0
    # delete unknown listbox content
    unknownlb.delete(0, END)
    # retrieve textbox contents
    inputText = textbox1.get("1.0", 'end-1c')
#    inputText = re.sub('[^a-zA-Z]+', ' ', inputText)
    intokens = nltk.word_tokenize(inputText.lower())
    # delete textbox contents
    textbox1.delete(1.0, END)
    # dictionary lookup
    # write word by word to textbox
    for nword in intokens:
        # ignore list of words that contains number and special characters
        if(nword.isalpha()):
            try:
                index = dictionarylb.get(0, "end").index(nword)
            except ValueError:
                index = -1
            if (index == -1):
                # select searched word
                unknownlb.insert(count, nword)
                textbox1.insert(END, nword + " ", 'RED')
                # highlight the misspelled word
                textbox1.tag_config('RED', foreground="red")
                count+=1
            else:
                # write actual correct words
                nnword = nword + " "
                textbox1.insert(END, nnword)
        else:
            # write actual numbers and special characters
            nnword = nword + " "
            textbox1.insert(END, nnword)

    if(count!=0):
        # show messagebox
        tkinter.messagebox.showinfo('Spell Check', 'Misspelled word(s) found: ' + str(count))
    else:
        # show messagebox
        tkinter.messagebox.showinfo('Spell Check', 'No misspelled word is found!')

# function to get suggestion of correct words by using Levenshtein edit distance
def getSuggestion():
    # get current highlighted word / cursor selected word
    s = unknownlb.curselection()
    # check if any word is selected or not
    if not s:
        tkinter.messagebox.showinfo('Spell Check', 'Please choose a word to correct.')
    else:
        # delete contents of suggestion listbox
        suggestedlb.delete(0, END)
        # apply Levenshtein edit distance to words in dictionary
        # insert list of suggested words to the listbox
        for x in dictionarylb.get(0, END):
            # get the operation cost
            med = levenshtein(unknownlb.get(s), x)
            # set the med limit up to 10 operation costs
            if (med < 10):
                suggestedlb.insert(0, str(med) + " " + x)
        # insert misspelled word (unchanged)
        suggestedlb.insert(0, "0 " + unknownlb.get(s))
        hiddenEntry.delete(0, END)
        hiddenEntry.insert(0, unknownlb.get(s))

        # sort listbox contents
        temp_list = list(suggestedlb.get(0, END))
        temp_list.sort(key=str.lower)
        suggestedlb.delete(0, END)
        for item in temp_list:
            suggestedlb.insert(END, item)
        # show messagebox
        tkinter.messagebox.showinfo('Spell Correction', 'The correct word has been suggested!')

# function to correct misspelled word
def changeSpell():
    # get misspelled word
    oldText = hiddenEntry.get()
    # get selected suggested word (chosen by the user)
    t = suggestedlb.curselection()
    # check if any suggested word is selected
    if not t:
        tkinter.messagebox.showinfo('Spell Check', 'Please choose a suggested word.')
    else:
        # change misspelled word to suggested word
        newText = suggestedlb.get(t)
        inputText = textbox1.get("1.0", 'end-1c')
        intokens = nltk.word_tokenize(inputText.lower())
        textbox1.delete(1.0, END)
        for nword in intokens:
            if nword==oldText:
                # remove the MED
                nword = newText[2:] + " "
                textbox1.insert(END, nword)
            else:
                nword = nword + " "
                textbox1.insert(END, nword)
        # show messagebox
        tkinter.messagebox.showinfo('Spell Correction', 'The misspelled word has been corrected!')
        suggestedlb.delete(0, END)
        spellCheck()

# exit program
def quitProgram():
    exit(0)

# create menu bar
menu = Menu(root)
root.config(menu=menu)
subMenu = Menu(menu)
menu.add_cascade(label="Menu", menu=subMenu)
subMenu.add_command(label="Load Text File", command=browseFileTokenize)
subMenu.add_command(label="Load PDF File", command=browsepdfFileTokenize)
subMenu.add_separator()
subMenu.add_command(label="Exit", command=quitProgram)

# create buttons
searchButton = Button(root, text="Search", command=searchItem)
spellcheckButton = Button(root, text="Spell Check", command=spellCheck)
suggestButton = Button(root, text="Get Suggestion", command=getSuggestion)
changeButton = Button(root, text="Change", command=changeSpell)

# create labels
typeLabel = Label(root, text="Type Here:")
dictLabel = Label(root, text="Dictionary List:")
searchLabel = Label(root, text="Search:")
wordLabel = Label(root, text="Total Words:")
unknownLabel = Label(root, text="Unknown Word(s):")
suggestedLabel = Label(root, text="Suggested Correct Word(s):")

# create text entries
searchEntry = Entry(root, width=22)
wordEntry = Entry(root, width=8)
hiddenEntry = Entry(root, width=20)

# create listboxes
dictionarylb = Listbox(root, height=20, width=30)
unknownlb = Listbox(root, height=8, width=30)
suggestedlb = Listbox(root, height=8, width=30)

# create textbox
textbox1 = Text(root, height=10, width=55)

# display management
textbox1.place(x=15, y=40)
typeLabel.place(x=15, y=20)
dictLabel.place(x=500, y=20)
dictionarylb.place(x=500, y=40)
searchLabel.place(x=500, y=390)
searchEntry.place(x=500, y=410)
searchButton.place(x=640, y=405)
wordLabel.place(x=555, y=372)
wordEntry.place(x=630,y=374)
unknownLabel.place(x=15,y=250)
suggestedLabel.place(x=275,y=250)
unknownlb.place(x=15,y=270)
suggestedlb.place(x=275,y=270)
spellcheckButton.place(x=200,y=210)
suggestButton.place(x=60,y=405)
changeButton.place(x=340,y=405)

# infinite loop to keep window constantly displays
root.mainloop()