# Christopher P. Matthews
# christophermatthews1985@gmail.com
# Sacramento, CA, USA
# https://en.wikibooks.org/wiki/Algorithm_Implementation/Strings/Levenshtein_distance#Python
# substitution cost 1

def levenshtein(s, t):
    d = {}
    # set lenstr1 to be the length of s / word in text
    lenstr1 = len(s)
    # set lenstr2 to be the length of t / word in dictionary
    lenstr2 = len(t)
    # examine each character from s and t
    for i in range(-1, lenstr1 + 1):
        d[(i, -1)] = i + 1
    for j in range(-1, lenstr2 + 1):
        d[(-1, j)] = j + 1

    for i in range(lenstr1):
        for j in range(lenstr2):
            # if s[i] equals to t[j], no transformation is required, thus cost is 0
            if s[i] == t[j]:
                cost = 0
            else:
            # s[i] not equals to t[j], thus substitution cost will be set to 2
                cost = 2
            # set cell d[i,j] of the matrix equal to the minimum of the following operations
            d[(i, j)] = min(
                d[(i - 1, j)] + 1,  # deletion
                d[(i, j - 1)] + 1,  # insertion
                d[(i - 1, j - 1)] + cost ,  # substitution
            )
            # continue iteration until all characters are covered from s and t

    # the final distance is found
    return d[lenstr1 - 1, lenstr2 - 1]

# if the cost of substitution is one, can use this code for MED
    # insert MED equals to 1
    # n = 0
    # if levenshtein(unknownlb.get(s), x) == 1:
    #    suggestedlb.insert(n, "1 " + x)
    #    n+=1
    # insert MED equals to 2
    # elif levenshtein(unknownlb.get(s), x) == 2:
    #    suggestedlb.insert(n, "2 " + x)
    #    n+=1


#testing
# print(levenshtein("intention","execution"))
# print(levenshtein("sewe","sewer"))
# print(levenshtein("balls","alls"))
# print(levenshtein("execution","intention"))
# print(levenshtein("sewer","rewes"))
# print("\n")

# Bernd Klein (2011-2017)
# source code available from https://www.python-course.eu/levenshtein_distance.php
# allow setting substitution cost of 1 or 2
# def iterative_levenshtein(s, t, costs=(1, 1, 1)):
#     """
#         iterative_levenshtein(s, t) -> ldist
#         ldist is the Levenshtein distance between the strings
#         s and t.
#         For all i and j, dist[i,j] will contain the Levenshtein
#         distance between the first i characters of s and the
#         first j characters of t
#
#         costs: a tuple or a list with three integers (d, i, s)
#                where d defines the costs for a deletion
#                      i defines the costs for an insertion and
#                      s defines the costs for a substitution
#     """
#     rows = len(s) + 1
#     cols = len(t) + 1
#     deletes, inserts, substitutes = costs
#
#     dist = [[0 for x in range(cols)] for x in range(rows)]
#     # source prefixes can be transformed into empty strings
#     # by deletions:
#     for row in range(1, rows):
#         dist[row][0] = row * deletes
#     # target prefixes can be created from an empty source string
#     # by inserting the characters
#     for col in range(1, cols):
#         dist[0][col] = col * inserts
#
#     for col in range(1, cols):
#         for row in range(1, rows):
#             if s[row - 1] == t[col - 1]:
#                 cost = 0
#             else:
#                 cost = substitutes
#             dist[row][col] = min(dist[row - 1][col] + deletes,
#                                  dist[row][col - 1] + inserts,
#                                  dist[row - 1][col - 1] + cost)  # substitution
#
#     return dist[row][col]
#
# #testing
# print(iterative_levenshtein("intention","execution", costs=(1,1,2)))
# print(iterative_levenshtein("sewe","sewer", costs=(1,1,2)))
# print(iterative_levenshtein("balls","alls", costs=(1,1,2)))
# print(iterative_levenshtein("execution","intention", costs=(1,1,2)))
# print(iterative_levenshtein("sewer","rewes", costs=(1,1,2)))
